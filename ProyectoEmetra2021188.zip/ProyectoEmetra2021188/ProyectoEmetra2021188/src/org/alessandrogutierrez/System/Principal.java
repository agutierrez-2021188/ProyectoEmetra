/*
    Alessandro Emanuel Gutiérrez Boc
    Carné: 2021-188
    IN5AV
    Fecha de Creación:
    26/09/2022.
    Fechas de modificación:
    26/09/2022, 27/09/2022, 26/09/2022
*/

package org.alessandrogutierrez.System;

import java.io.InputStream;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import org.alessandrogutierrez.Bean.Vecino;
import org.alessandrogutierrez.Controller.MenuPrincipalController;
import org.alessandrogutierrez.Controller.VecinosController;
import org.alessandrogutierrez.Controller.VehiculosController;


public class Principal extends Application {
    private Scene escena;
    private Stage escenarioPrincipal;
    private final String PAQUETE_VISTA = "/org/alessandrogutierrez/View/";
    
    @Override
    public void start(Stage escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
        ventanaMenuPrincipal();
        escenarioPrincipal.show();
    }
       
    public void ventanaMenuPrincipal(){
        try{
        MenuPrincipalController menu = (MenuPrincipalController) cambiarEscena("menuPrincipal.fxml", 650, 400);
        menu.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }   

    }   
    
    public void ventanaVecinos(){
        try{
            VecinosController vecino = (VecinosController) cambiarEscena("vecinosView.fxml", 1144, 450);
            vecino.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void ventanaVehiculos(){
        try{
            VehiculosController vehi = (VehiculosController) cambiarEscena ("vehiculosView.fxml",960,400);
            vehi.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void ventanaProgramador(){
        try{
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        launch(args);
    }
// --
    
    public Stage getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Stage escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }

    
    
    public Initializable cambiarEscena(String fxml, int ancho, int alto) throws Exception{
        Initializable resultado = null;
        FXMLLoader cargadorFXML = new FXMLLoader();
        InputStream archivo = Principal.class.getResourceAsStream(PAQUETE_VISTA+fxml);
        cargadorFXML.setBuilderFactory(new JavaFXBuilderFactory());
        cargadorFXML.setLocation(Principal.class.getResource(PAQUETE_VISTA+fxml));
        escena = new Scene((AnchorPane)cargadorFXML.load(archivo),ancho,alto);
        escenarioPrincipal.setScene(escena);
        escenarioPrincipal.sizeToScene();
        resultado = (Initializable)cargadorFXML.getController();
        return resultado;
    }
}
