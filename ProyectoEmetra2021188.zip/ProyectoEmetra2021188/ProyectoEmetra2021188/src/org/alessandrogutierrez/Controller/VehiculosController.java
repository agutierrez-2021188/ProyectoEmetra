
package org.alessandrogutierrez.Controller;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.swing.JOptionPane;
import org.alessandrogutierrez.Bean.Vecino;
import org.alessandrogutierrez.Bean.Vehiculo;
import org.alessandrogutierrez.DB.Conexion;
import org.alessandrogutierrez.System.Principal;

public class VehiculosController implements Initializable{
    private Principal escenarioPrincipal;
    
    private enum operaciones {NUEVO, EDITAR, ELIMINAR, NINGUNO, GUARDAR, ACTUALIZAR};
    private operaciones tipoDeOperacion = operaciones.NINGUNO;
    private ObservableList<Vecino> listaVecinos;
    private ObservableList<Vehiculo> listaVehiculos;
    @FXML private TextField txtPlaca;
    @FXML private TextField txtMarca;
    @FXML private TextField txtModelo;
    @FXML private TextField txtTipoDeVehiculo;
    @FXML private TextField txtNIT;
    @FXML private TableView tblVehiculos;
    @FXML private TableColumn colPlaca;
    @FXML private TableColumn colMarca;
    @FXML private TableColumn colModelo;
    @FXML private TableColumn colTipoDeVehiculo;
    @FXML private TableColumn colNIT;
    @FXML private Button btnNuevo;
    @FXML private Button btnEditar;
    @FXML private Button btnEliminar;
    @FXML private Button btnReporte;   
    @FXML private ComboBox cmbNIT;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
      cargarDatos();
        cmbNIT.setItems(getVecino());
        cmbNIT.setDisable(true);  
        btnReporte.setDisable(true);
        desactivarControles();
    }
    
    public ObservableList<Vecino> getVecino(){
        ArrayList<Vecino> lista = new ArrayList<>();
        try{
            PreparedStatement procedimiento = Conexion.getInstancia().getConexion().prepareCall("{call sp_ListarVecinos ()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Vecino(
                        resultado.getString("NIT"),
                        resultado.getLong("DPI"),
                        resultado.getString("nombres"),
                        resultado.getString("apellidos"),
                        resultado.getString("direccion"),
                        resultado.getString("municipalidad"),
                        resultado.getInt("codigoPostal"),
                        resultado.getString("telefono")
                ));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return listaVecinos = FXCollections.observableArrayList(lista);
    }

    public ObservableList<Vehiculo> getVehiculo(){
        ArrayList<Vehiculo> lista = new ArrayList<>();
        try{
            PreparedStatement procedimiento = Conexion.getInstancia().getConexion().prepareCall("{call sp_ListarVehiculos ()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Vehiculo ( resultado.getString("placa"),
                                         resultado.getString("marca"),
                                         resultado.getString("modelo"),
                                         resultado.getString("tipoDeVehiculo"),
                                         resultado.getString("NIT")
                ));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return listaVehiculos = FXCollections.observableArrayList(lista);
    }    

    public Vecino buscarVecino(String cNit){
        Vecino resultado = null;
        try{
            PreparedStatement procedimiento = Conexion.getInstancia().getConexion().prepareCall("{call sp_BuscarVecino(?)}");
            procedimiento.setString(1, cNit);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new Vecino(registro.getString("NIT"),
                                    registro.getLong("DPI"),
                                    registro.getString("nombres"),
                                    registro.getString("apellidos"),
                                    registro.getString("direccion"),
                                    registro.getString("municipalidad"),
                                    registro.getInt("codigoPostal"),
                                    registro.getString("telefono"));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return resultado;
    }
    
    public void cargarDatos(){
        tblVehiculos.setItems(getVehiculo());
        colPlaca.setCellValueFactory(new PropertyValueFactory<Vehiculo, String>("placa"));
        colMarca.setCellValueFactory(new PropertyValueFactory<Vehiculo, String>("marca"));
        colModelo.setCellValueFactory(new PropertyValueFactory<Vehiculo, String>("modelo"));
        colTipoDeVehiculo.setCellValueFactory(new PropertyValueFactory<Vehiculo, String>("tipoDeVehiculo"));
        colNIT.setCellValueFactory(new PropertyValueFactory<Vehiculo, String>("NIT"));
    }    
    
    public void seleccionarElemento(){
        try{
            txtPlaca.setText(((Vehiculo)tblVehiculos.getSelectionModel().getSelectedItem()).getPlaca());
            txtMarca.setText(((Vehiculo)tblVehiculos.getSelectionModel().getSelectedItem()).getMarca());
            txtModelo.setText(((Vehiculo)tblVehiculos.getSelectionModel().getSelectedItem()).getModelo());
            txtMarca.setText(((Vehiculo)tblVehiculos.getSelectionModel().getSelectedItem()).getMarca());
            txtTipoDeVehiculo.setText(((Vehiculo)tblVehiculos.getSelectionModel().getSelectedItem()).getTipoDeVehiculo());
            cmbNIT.getSelectionModel().select(buscarVecino(((Vehiculo)tblVehiculos.getSelectionModel().getSelectedItem()).getNIT()));        
        }catch(Exception e){
             JOptionPane.showMessageDialog(null,"Debe seleccionar un registro");
        }
     
    }
    
    public void guardar(){
        Vehiculo registro = new Vehiculo();
        registro.setPlaca(txtPlaca.getText());
        registro.setMarca(txtMarca.getText());
        registro.setModelo(txtModelo.getText());
        registro.setTipoDeVehiculo(txtTipoDeVehiculo.getText());
        registro.setNIT(((Vecino)cmbNIT.getSelectionModel().getSelectedItem()).getNIT());
        try{
            PreparedStatement procedimiento = Conexion.getInstancia().getConexion().prepareCall("{call sp_AgregarVehiculo(?,?,?,?,?)}");
            procedimiento.setString(1, registro.getPlaca());
            procedimiento.setString(2, registro.getMarca());
            procedimiento.setString(3, registro.getModelo());
            procedimiento.setString(4, registro.getTipoDeVehiculo());
            procedimiento.setString(5, registro.getNIT());
            procedimiento.execute();
            listaVehiculos.add(registro);
            cargarDatos();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void nuevo(){
        switch(tipoDeOperacion){
            case NINGUNO:
                activarControles();
                limpiarControles();
                btnNuevo.setText("Guardar");
                btnEliminar.setText("Cancelar");
                btnEditar.setDisable(true);
                tipoDeOperacion = VehiculosController.operaciones.GUARDAR;
                break;
            case GUARDAR:
                    guardar();
                    desactivarControles();
                    limpiarControles();
                    btnNuevo.setText("Nuevo");
                    btnEliminar.setText("Eliminar");
                    btnEditar.setDisable(false);
                    tipoDeOperacion = VehiculosController.operaciones.NINGUNO;
                break;
        }
    }        
    
    public void eliminar(){
        switch(tipoDeOperacion){
            case GUARDAR: 
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                btnEditar.setDisable(false);
                desactivarControles();
                limpiarControles();
                tipoDeOperacion = VehiculosController.operaciones.NINGUNO;
            break;
            default:
               if(tblVehiculos.getSelectionModel().getSelectedItem()!= null){
                   int respuesta = JOptionPane.showConfirmDialog(null, "Estas seguro de eliminar estos datos?", "Eliminar registro", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                   if(respuesta == JOptionPane.YES_OPTION){
                       try{
                       PreparedStatement procedimiento = Conexion.getInstancia().getConexion().prepareCall("{call sp_EliminarVehiculo(?)}");
                       procedimiento.setString(1, (((Vehiculo)tblVehiculos.getSelectionModel().getSelectedItem()).getPlaca()));
                       procedimiento.execute();
                       listaVehiculos.remove(tblVehiculos.getSelectionModel().getSelectedIndex());
                       limpiarControles();    
                       }catch(Exception e){
                           e.printStackTrace();
                       }
                   }else{
                       limpiarControles();
                   }
               }else{
                   JOptionPane.showMessageDialog(null, "Debe seleccionar un registro");
               } 
            break;
        }
    }    

    public void editar(){
        switch(tipoDeOperacion){
            case NINGUNO:
                if(tblVehiculos.getSelectionModel().getSelectedItem() != null){
                    btnEditar.setText("Actualizar");
                    btnNuevo.setDisable(true);
                    btnEliminar.setDisable(true);
                    btnReporte.setText("Cancelar");
                    btnReporte.setDisable(false);
                    activarControles();
                    tipoDeOperacion = VehiculosController.operaciones.ACTUALIZAR;
                }else{
                    JOptionPane.showMessageDialog(null,"Debe seleccionar un registro");
                }
                break;
            case ACTUALIZAR:
                    actualizar();
                    btnEditar.setText("Editar");
                    btnReporte.setText("PMT");
                    btnNuevo.setDisable(false);
                    btnEliminar.setDisable(false);  
                    desactivarControles();
                    limpiarControles();
                    cargarDatos();
                    tipoDeOperacion = VehiculosController.operaciones.NINGUNO;
                break;
        }
    }    
    
    
    public void reporte(){
        switch(tipoDeOperacion){
            case ACTUALIZAR:
                    desactivarControles();
                    limpiarControles();
                    btnEditar.setText("Editar");
                    btnReporte.setText("PMT");
                    btnNuevo.setDisable(false);
                    btnEliminar.setDisable(false);
                    tipoDeOperacion = operaciones.NINGUNO;               
                break;          
        }        
    }     
    
    public void actualizar(){
        try{
            PreparedStatement procedimiento = Conexion.getInstancia().getConexion().prepareCall("{call sp_EditarVehiculo(?,?,?,?)}");
            Vehiculo registro = (Vehiculo)tblVehiculos.getSelectionModel().getSelectedItem();
            registro.setMarca(txtMarca.getText());
            registro.setModelo(txtModelo.getText());
            registro.setTipoDeVehiculo(txtTipoDeVehiculo.getText());
            procedimiento.setString(1, registro.getPlaca());
            procedimiento.setString(2, registro.getMarca());
            procedimiento.setString(3, registro.getModelo());
            procedimiento.setString(4, registro.getTipoDeVehiculo());
            procedimiento.execute();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
        
    
   public void desactivarControles(){
        txtPlaca.setEditable(false);
        txtMarca.setEditable(false);
        txtModelo.setEditable(false);
        txtTipoDeVehiculo.setEditable(false);
        cmbNIT.setDisable(true);
    }
   
    public void activarControles(){
        txtPlaca.setEditable(true);
        txtMarca.setEditable(true);
        txtModelo.setEditable(true);
        txtTipoDeVehiculo.setEditable(true);
        cmbNIT.setDisable(false);
    }
    
    public void limpiarControles(){
        txtPlaca.clear();
        txtMarca.clear();
        txtModelo.clear();
        txtTipoDeVehiculo.clear();
        cmbNIT.setValue(null);
    }
    
    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }    
    
    public void menuPrincipal(){
        escenarioPrincipal.ventanaMenuPrincipal();
    }
    
}
