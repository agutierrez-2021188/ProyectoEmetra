/*
	Alessandro Emanuel Gutiérrez Boc
    Carné: 2021-188
    IN5AV
    Fecha de Creación:
    26/09/2022.
    Fechas de modificación:
    26/09/2022, 27/09/2022, 26/09/2022
*/

Drop database if exists DBEmetra2022;
Create database DBEmetra2022;
Use DBEmetra2022;

Create table Vecinos (
	NIT varchar (15)	,
    DPI bigint (13),
    nombres varchar(100),
    apellidos varchar(100),
    direccion varchar(200),
    municipalidad varchar(45),
    codigoPostal int,
    telefono varchar(8),
	primary key PK_NIT (NIT)
);

Create table Vehiculos(
	placa varchar (15),
    marca varchar (45),
    modelo varchar (45),
    tipoDeVehiculo varchar (60),
    NIT varchar (15),
    primary key PK_placa (placa),
    constraint foreign key FK_Vehiculos_Vecinos (NIT)
		references Vecinos (NIT)
); 
	

-- #------------ Vecinos -----------#

-- Agregar
Delimiter $$
Create procedure sp_AgregarVecino(in NIT varchar (15), in DPI bigint (13), in nombres varchar(100), 
			in apellidos varchar(100), in direccion varchar(200), in muncipipalidad varchar(45), in codigoPostal int, in telefono varchar(8))
	Begin
		Insert into Vecinos (NIT, DPI, nombres, apellidos, direccion, municipalidad, codigoPostal, telefono) 
			values (NIT, DPI, nombres, apellidos, direccion, municipalidad ,codigoPostal, telefono);		
	End $$
Delimiter ; 

call sp_AgregarVecino ('123456789', '12345678910', "Alessandro Emanuel", "Gutierrez Boc", "Zona 6 de mixco", "Mixco",'1', "12345678");
call sp_AgregarVecino ('987654321', '12345678910', "Alessandro Emanuel", "Gutierrez Boc", "Zona 6 de mixco", "Mixco",'1', "12345678");
call sp_AgregarVecino ('745236', '12345678910', "Douglas ", "Salazar", "Zona 6 de mixco", "Mixco",'1', "12345678");

-- Listar
Delimiter $$
	Create procedure sp_ListarVecinos()
	Begin
		Select 
        V.NIT, 
        V.DPI, 
        V.nombres, 
        V.apellidos, 
        V.direccion, 
        V.municipalidad,
        V.codigoPostal, 
        V.telefono
        from Vecinos V;
    End $$
Delimiter ;

call sp_ListarVecinos ();

-- Buscar
Delimiter $$
	Create procedure sp_BuscarVecino(in cNit varchar(15) )
	Begin
		Select 
        V.NIT, 
        V.DPI, 
        V.nombres, 
        V.apellidos, 
        V.direccion, 
        V.municipalidad,
        V.codigoPostal, 
        V.telefono
        from Vecinos V where V.NIT=cNit;
    End $$
Delimiter ;

call sp_BuscarVecino("987654321");

-- Eliminar 
Delimiter $$
	Create procedure sp_EliminarVecino(in codVecino varchar (15))
	Begin
		Delete from Vecinos
        where NIT = codVecino;
    End $$
Delimiter ;

call sp_EliminarVecino ("123456789");


-- Editar

Delimiter $$
	Create procedure sp_EditarVecino(in nit varchar (15), in dpi bigint (13), in nomb varchar(100), 
			in apell varchar(100), in direc varchar(200), in muncipalid varchar(45), in codPostal int, in telefon varchar(8))
	Begin
		update Vecinos V set
		V.NIT = nit,
        V.DPI = dpi,
        V.nombres = nomb, 
        V.apellidos = apell, 
        V.direccion = direc,
        V.municipalidad = muncipalid,
        V.codigoPostal = codPostal,
        V.telefono = telefon
        where V.NIT = nit ; 
    End $$
Delimiter ;

call sp_EditarVecino ('987654321', '12345678910', "Alessandro Emanuel", "Gutierrez Boc", "Zona 6 de mixco", "Mixco",'1', "12345678");



-- #------------ Vehiculos -----------#

-- Agregar
Delimiter $$
Create procedure sp_AgregarVehiculo( in placa varchar (15), in marca varchar (45), in modelo varchar (45), 
	in tipoDeVehiculo varchar (60), in NIT varchar (15))
	Begin
		Insert into Vehiculos (placa, marca, modelo, tipoDeVehiculo, NIT) 
			values (placa, marca, modelo, tipoDeVehiculo, NIT);		
	End $$
Delimiter ; 

call sp_AgregarVehiculo ("C12345", "Yoyota", "Sport 2008", "Deportivo", "987654321");
call sp_AgregarVehiculo ("C54321", "Yoyota", "Sport 2008", "Deportivo", "987654321");



-- Listar 
Delimiter $$
	Create procedure sp_ListarVehiculos()
	Begin
		Select 
        V.placa, 
        V.marca, 
        V.modelo, 
        V.tipoDeVehiculo, 
        V.NIT
		from Vehiculos V;
    End $$
Delimiter ;

call sp_ListarVehiculos();

-- Buscar
Delimiter $$
	Create procedure sp_BuscarVehiculo(in plac varchar (15))
	Begin
		Select 
        V.placa, 
        V.marca, 
        V.modelo, 
        V.tipoDeVehiculo, 
        V.NIT
		from Vehiculos V where V.placa = plac;
    End $$
Delimiter ;

call sp_BuscarVehiculo("C54321");

-- Eliminar 
Delimiter $$
	Create procedure sp_EliminarVehiculo(in plac varchar (15))
	Begin
		Delete from Vehiculos where placa = plac;
    End $$
Delimiter ;

call sp_EliminarVehiculo("C12345");

-- Editar 

Delimiter $$
	Create procedure sp_EditarVehiculo(in plac varchar (15), in marc varchar (45), in model varchar (45), 
		in tDVehiculo varchar (60))
	Begin
		update Vehiculos V set
        V.marca = marc, 
        V.modelo = model, 
        V.tipoDeVehiculo = tDVehiculo
        where V.placa =plac; 
    End $$
Delimiter ;

call sp_EditarVehiculo ("C54321", "BMW", "Sport 2008", "Deportivo");



